package com.lirapay.sim

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.composed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.*

val Green = Color(0xFF0B3D3A); val BG = Color(0xFFF4F6F5); val Gold = Color(0xFFD9B86A)
val themes = listOf(
    listOf(Color(0xFF0B3D3A), Color(0xFF1B5A52)), listOf(Color(0xFF0A1F44), Color(0xFF2347A0)),
    listOf(Color(0xFF111111), Color(0xFF4A4030)), listOf(Color(0xFF4A148C), Color(0xFFAD1457)))
val themeNames = listOf("Изумруд", "Сапфир", "Оникс", "Гранат")

fun money(v: Double) = DecimalFormat("#,##0.00", DecimalFormatSymbols(Locale("tr", "TR"))).format(v) + " ₺"
fun order(k: String) = if (k.startsWith("t")) k.drop(1).toInt() else 10
fun String.num() = replace(" ", "").replace(',', '.').toDoubleOrNull()

data class Card(val id: String, val name: String, val last4: String, val exp: String, val theme: Int, val balance: Double)
data class Tx(val id: String, val cardId: String, val title: String, val desc: String, val amount: Double, val kind: String, val time: Long)

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("lirapay", 0)
    var cards by mutableStateOf(listOf<Card>()); var txs by mutableStateOf(listOf<Tx>())
    var pin by mutableStateOf("1234"); var holder by mutableStateOf("ALEX MORGAN"); var hidden by mutableStateOf(false)
    var premium by mutableStateOf(false); var notifs by mutableStateOf(setOf<Int>())
    init {
        val c = sp.getString("cards", null)
        if (c == null) reset() else {
            cards = JSONArray(c).let { a -> (0 until a.length()).map { a.getJSONObject(it).let { o ->
                Card(o.getString("id"), o.getString("n"), o.getString("l"), o.getString("e"), o.getInt("t"), o.getDouble("b")) } } }
            txs = JSONArray(sp.getString("txs", "[]")).let { a -> (0 until a.length()).map { a.getJSONObject(it).let { o ->
                Tx(o.getString("id"), o.getString("c"), o.getString("ti"), o.getString("d"), o.getDouble("a"), o.getString("k"), o.getLong("tm")) } } }
            pin = sp.getString("pin", "1234")!!; holder = sp.getString("holder", holder)!!; hidden = sp.getBoolean("hid", false)
            premium = sp.getBoolean("prem", false); notifs = sp.getString("nf", "")!!.split(",").mapNotNull { it.toIntOrNull() }.toSet()
        }
    }
    fun save() {
        sp.edit().putString("cards", JSONArray().apply { cards.forEach { put(JSONObject().put("id", it.id).put("n", it.name).put("l", it.last4).put("e", it.exp).put("t", it.theme).put("b", it.balance)) } }.toString())
            .putString("txs", JSONArray().apply { txs.forEach { put(JSONObject().put("id", it.id).put("c", it.cardId).put("ti", it.title).put("d", it.desc).put("a", it.amount).put("k", it.kind).put("tm", it.time)) } }.toString())
            .putString("pin", pin).putString("holder", holder).putBoolean("hid", hidden).putBoolean("prem", premium).putString("nf", notifs.joinToString(",")).apply()
    }
    fun reset() { cards = listOf(Card("1", "Лира Pay", "4821", "09/29", 0, 200.0)); txs = emptyList(); pin = "1234"; holder = "ALEX MORGAN"; hidden = false; premium = false; notifs = emptySet(); save() }
    fun upd(id: String, f: (Card) -> Card) { cards = cards.map { if (it.id == id) f(it) else it } }
    fun apply(cardId: String, title: String, desc: String, amt: Double, kind: String) {
        upd(cardId) { it.copy(balance = it.balance + amt) }
        txs = listOf(Tx(UUID.randomUUID().toString(), cardId, title, desc, amt, kind, System.currentTimeMillis())) + txs; save()
    }
    fun togglePrem() { premium = !premium; save() }
    fun toggleNf(i: Int) { notifs = if (i in notifs) notifs - i else notifs + i; save() }
    fun setBal(id: String, v: Double) { upd(id) { it.copy(balance = v) }; save() }
    fun edit(t: Tx, title: String, desc: String, amt: Double) {
        upd(t.cardId) { it.copy(balance = it.balance - t.amount + amt) }
        txs = txs.map { if (it.id == t.id) it.copy(title = title, desc = desc, amount = amt) else it }; save()
    }
    fun del(t: Tx) { upd(t.cardId) { it.copy(balance = it.balance - t.amount) }; txs = txs.filter { it.id != t.id }; save() }
    fun addCard(name: String, theme: Int) {
        val l4 = (1000..9999).random().toString(); val y = Calendar.getInstance().get(Calendar.YEAR) % 100 + 4
        cards = cards + Card(UUID.randomUUID().toString(), name.ifBlank { "Лира Pay" }, l4, "%02d/%02d".format((1..12).random(), y), theme, 0.0); save()
    }
    fun delCard(id: String) { if (cards.size > 1) { cards = cards.filter { it.id != id }; txs = txs.filter { it.cardId != id }; save() } }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); val s = Store(this); setContent { MaterialTheme { App(s) } } }
}

@Composable fun App(s: Store) = CompositionLocalProvider(LocalPremium provides s.premium) { AppBody(s) }

@Composable fun AppBody(s: Store) {
    var tab by remember { mutableIntStateOf(0) }
    var sub by remember { mutableStateOf<String?>(null) }
    var sel by remember { mutableIntStateOf(0) }
    val card = s.cards[sel.coerceIn(0, s.cards.lastIndex)]
    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding()) {
        Box(Modifier.fillMaxWidth().background(Color(0xFFFFF3CD)).padding(4.dp), Alignment.Center) {
            Text("SIMULATOR / ДЕМО · вымышленный банк", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF7A5C00)) }
        Box(Modifier.weight(1f)) {
            AnimatedContent(sub ?: "t$tab", label = "nav", transitionSpec = {
                val fwd = order(targetState) >= order(initialState)
                (fadeIn(tween(320)) + slideInHorizontally(tween(340, easing = FastOutSlowInEasing)) { if (fwd) it / 5 else -it / 5 }) togetherWith
                    (fadeOut(tween(200)) + slideOutHorizontally(tween(340, easing = FastOutSlowInEasing)) { if (fwd) -it / 5 else it / 5 })
            }) { k ->
                when (k) {
                    "history" -> History(s) { sub = null }
                    "admin" -> Admin(s, card) { sub = null }
                    else -> when (k) {
                        "t0" -> Home(s, card, { sel = it }) { if (it == "pay") { tab = 2; sub = null } else sub = it }
                        "t1" -> Cards(s, card) { sel = it }
                        "t2" -> Pay(s, card)
                        else -> Profile(s) { sub = it }
                    }
                }
            }
        }
        if (sub == null) NavigationBar(containerColor = Color.White) {
            listOf("⌂" to "Главная", "▭" to "Карты", "⇄" to "Платежи", "☺" to "Профиль").forEachIndexed { i, (ic, l) ->
                NavigationBarItem(tab == i, { tab = i }, { Text(ic, fontSize = 20.sp) }, label = { Text(l, fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(selectedTextColor = Green, indicatorColor = Color(0xFFDCEBE8))) }
        }
    }
}

val LocalPremium = compositionLocalOf { false }
val funNotifs = listOf(
    "☕" to "Кэшбэк за кофе: +0,01 ₺",
    "🥩" to "Лимит на шашлыки исчерпан. До пятницы только салат",
    "🤝" to "Друг просит в долг. Рекомендуем не отвечать",
    "🐱" to "Ваш кот проверил баланс. Он впечатлён",
    "😄" to "Комиссия за хорошее настроение: 0 ₺. Продолжайте",
    "🏆" to "Лира Pay гордится вами: вы дожили до конца месяца")
val privileges = listOf(
    "Личный менеджер: кот Барсик (на связи по вторникам)",
    "Лимит на шашлыки увеличен до «неограниченно»",
    "Приоритетная поддержка: мы подумаем, что вам ответить",
    "Бесплатное обслуживание воображаемого счёта",
    "Почётное звание «Богатый духом»")

@Composable fun NotifCard(n: Pair<String, String>, off: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp).background(Color(0xFFE8F1EF), RoundedCornerShape(16.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(n.first, fontSize = 20.sp); Spacer(Modifier.width(10.dp))
        Text(n.second, Modifier.weight(1f), fontSize = 13.sp, color = Green, fontWeight = FontWeight.Medium)
        Text("✕", color = Color.Gray, modifier = Modifier.clickable { off() }.padding(6.dp)) }
}

@Composable fun McLogo() = Canvas(Modifier.size(56.dp, 34.dp)) {
    val r = size.height / 2; val a = Offset(r, r); val b = Offset(size.width - r, r)
    drawCircle(Color(0xFFEB001B), r, a); drawCircle(Color(0xFFF79E1B), r, b)
    val p = Path.combine(PathOperation.Intersect, Path().apply { addOval(Rect(a, r)) }, Path().apply { addOval(Rect(b, r)) })
    drawPath(p, Color(0xFFFF5F00))
}

@Composable fun CardFace(c: Card, holder: String, hide: Boolean) {
    val prem = LocalPremium.current
    Box(Modifier.fillMaxSize().clip(RoundedCornerShape(26.dp))
        .background(Brush.linearGradient(themes[c.theme % themes.size]))
        .border(if (prem) 2.dp else 0.dp, Gold, RoundedCornerShape(26.dp)).padding(22.dp)) {
        Canvas(Modifier.matchParentSize()) { drawCircle(Color.White.copy(alpha = .06f), size.width * .35f, Offset(size.width * .95f, 0f)) }
        Row(Modifier.fillMaxWidth().align(Alignment.TopStart), Arrangement.SpaceBetween) {
            Text(c.name + if (prem) "  ★ PREMIUM" else "", color = if (prem) Gold else Color.White, fontWeight = FontWeight.Bold, fontSize = if (prem) 15.sp else 18.sp)
            Text(if (hide) "••••• ₺" else money(c.balance), color = Color.White.copy(alpha = .85f), fontSize = 13.sp)
        }
        Box(Modifier.align(Alignment.CenterStart).padding(bottom = 6.dp).size(42.dp, 32.dp).clip(RoundedCornerShape(7.dp)).background(Gold))
        Column(Modifier.align(Alignment.BottomStart)) {
            Text("••••  ••••  ••••  ${c.last4}", color = Color.White, fontSize = 18.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(4.dp))
            Text(holder.uppercase(), color = Color.White, fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Text("${c.exp} · TRY · SIMULATOR / DEMO", color = Color.White.copy(alpha = .7f), fontSize = 10.sp)
        }
        Box(Modifier.align(Alignment.BottomEnd)) { McLogo() }
    }
}

@Composable fun CardBack(c: Card) {
    Box(Modifier.fillMaxSize().clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(themes[c.theme % themes.size].reversed()))) {
        Box(Modifier.fillMaxWidth().padding(top = 28.dp).height(44.dp).background(Color.Black.copy(alpha = .85f)))
        Column(Modifier.align(Alignment.BottomStart).padding(22.dp)) {
            Box(Modifier.fillMaxWidth(.65f).height(30.dp).clip(RoundedCornerShape(6.dp)).background(Color.White.copy(alpha = .9f)), Alignment.CenterStart) {
                Text("  DEMO · CVV отсутствует", fontSize = 11.sp, color = Color.DarkGray) }
            Spacer(Modifier.height(8.dp))
            Text("Виртуальная карта •• ${c.last4}", color = Color.White, fontSize = 12.sp)
            Text("SIMULATOR / DEMO · Лира Pay", color = Color.White.copy(alpha = .7f), fontSize = 10.sp)
        }
        Box(Modifier.align(Alignment.BottomEnd).padding(22.dp)) { McLogo() }
    }
}

@Composable fun CardView(c: Card, holder: String, hide: Boolean, mod: Modifier = Modifier, onTap: (() -> Unit)? = null) {
    val rot = remember(c.id) { Animatable(0f) }; val scope = rememberCoroutineScope()
    val snap = spring<Float>(dampingRatio = .55f, stiffness = 140f)
    val back = ((rot.value % 360f) + 360f) % 360f in 90f..270f
    fun settle() { scope.launch { rot.animateTo(Math.round(rot.value / 180f) * 180f, snap) } }
    Box(mod.fillMaxWidth().aspectRatio(1.6f)
        .graphicsLayer {
            rotationY = rot.value; cameraDistance = 16f * density
            val k = 1f - .07f * kotlin.math.abs(kotlin.math.sin(Math.toRadians(rot.value.toDouble()))).toFloat()
            scaleX = k; scaleY = k; shadowElevation = 28f; shape = RoundedCornerShape(26.dp)
        }
        .pointerInput(c.id) { detectHorizontalDragGestures(onDragEnd = { settle() }, onDragCancel = { settle() }) { ch, dx ->
            ch.consume(); scope.launch { rot.snapTo(rot.value + dx * .45f) } } }
        .pointerInput(c.id) { detectTapGestures {
            if (onTap != null) onTap() else scope.launch { rot.animateTo((Math.round(rot.value / 180f) + 1) * 180f, snap) } } }
    ) {
        if (back) Box(Modifier.fillMaxSize().graphicsLayer { rotationY = 180f }) { CardBack(c) } else CardFace(c, holder, hide)
    }
}

@Composable fun Appear(i: Int = 0, content: @Composable () -> Unit) {
    var v by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(60L * i.coerceAtMost(8)); v = true }
    AnimatedVisibility(v, enter = fadeIn(tween(350)) + slideInVertically(tween(350, easing = FastOutSlowInEasing)) { it / 4 }) { content() }
}

@Composable fun animMoney(t: Double): Double {
    var from by remember { mutableDoubleStateOf(t) }; val a = remember { Animatable(1f) }
    LaunchedEffect(t) { a.snapTo(0f); a.animateTo(1f, tween(800, easing = FastOutSlowInEasing)); from = t }
    return from + (t - from) * a.value
}

fun Modifier.press(onClick: () -> Unit) = composed {
    val src = remember { MutableInteractionSource() }; val p by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (p) .94f else 1f, spring(dampingRatio = .5f, stiffness = 500f), label = "press")
    graphicsLayer { scaleX = sc; scaleY = sc }.clickable(src, null, onClick = onClick)
}

@Composable fun TxRow(t: Tx) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Color.White, RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(t.title, fontWeight = FontWeight.Bold)
            Text("${t.desc} · ${SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ru")).format(Date(t.time))}", fontSize = 12.sp, color = Color.Gray) }
        Text((if (t.amount > 0) "+" else "") + money(t.amount), fontWeight = FontWeight.Bold,
            color = if (t.amount > 0) Color(0xFF1B7F4B) else Color(0xFFC62828))
    }
}

@Composable fun Tf(l: String, v: String, c: (String) -> Unit, num: Boolean = false, pw: Boolean = false) =
    OutlinedTextField(v, c, Modifier.fillMaxWidth().padding(vertical = 4.dp), label = { Text(l) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = if (num) KeyboardType.Decimal else KeyboardType.Text),
        visualTransformation = if (pw) PasswordVisualTransformation() else VisualTransformation.None)

@Composable fun Btn(t: String, mod: Modifier = Modifier.fillMaxWidth(), color: Color = Green, onClick: () -> Unit) =
    Button(onClick, mod, colors = ButtonDefaults.buttonColors(containerColor = color)) { Text(t) }

@Composable fun Home(s: Store, card: Card, pick: (Int) -> Unit, go: (String) -> Unit) {
    val total = animMoney(s.cards.sumOf { it.balance })
    Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp)) {
        Appear(0) { Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).border(if (s.premium) 2.dp else 0.dp, Gold, CircleShape).padding(if (s.premium) 3.dp else 0.dp).clip(CircleShape).background(Green), Alignment.Center) {
                Text(s.holder.split(" ").mapNotNull { it.firstOrNull() }.take(2).joinToString("").uppercase(), color = Color.White, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(12.dp))
            Column { Text("Добрый день", color = Color.Gray, fontSize = 13.sp); Row { Text(s.holder, fontSize = 20.sp, fontWeight = FontWeight.Bold); if (s.premium) Text("  ★ PREMIUM", color = Color(0xFFB8860B), fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterVertically)) } } } }
        Spacer(Modifier.height(14.dp))
        s.notifs.sorted().forEach { i -> key(i) { Appear(0) { NotifCard(funNotifs[i]) { s.toggleNf(i) } } } }
        Appear(1) { Column(Modifier.fillMaxWidth(), Alignment.CenterHorizontally) {
            CardView(card, s.holder, s.hidden)
            Text("Проведите по карте, чтобы повернуть", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(top = 8.dp)) } }
        Row(Modifier.fillMaxWidth().padding(8.dp), Arrangement.Center) {
            s.cards.forEachIndexed { i, c ->
                val on = c.id == card.id
                val d by animateDpAsState(if (on) 10.dp else 7.dp, label = "dot")
                val col by animateColorAsState(if (on) Green else Color.LightGray, label = "dotc")
                Box(Modifier.padding(4.dp).size(d).clip(CircleShape).background(col).clickable { pick(i) }) } }
        Appear(2) { Column {
            Text("Общий баланс", color = Color.Gray)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Crossfade(s.hidden, Modifier.weight(1f), label = "hide") { h ->
                    Text(if (h) "••••••" else money(total), fontSize = 32.sp, fontWeight = FontWeight.ExtraBold) }
                TextButton({ s.hidden = !s.hidden; s.save() }) { Text(if (s.hidden) "Показать" else "Скрыть", color = Green) } } } }
        Appear(3) { Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), Arrangement.spacedBy(10.dp)) {
            listOf("＋\nПополнить" to "admin", "→\nПеревести" to "pay", "▤\nВыписка" to "history").forEach { (t, k) ->
                Box(Modifier.weight(1f).press { go(k) }.clip(RoundedCornerShape(20.dp)).background(Color.White).padding(16.dp), Alignment.Center) {
                    Text(t, fontWeight = FontWeight.SemiBold, color = Green, textAlign = TextAlign.Center, fontSize = 13.sp) } } } }
        Text("Последние операции", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        if (s.txs.isEmpty()) Text("Операций пока нет", color = Color.Gray, modifier = Modifier.padding(8.dp))
        s.txs.take(5).forEachIndexed { i, t -> key(t.id) { Appear(i + 4) { TxRow(t) } } }
    }
}

@Composable fun Cards(s: Store, cur: Card, pick: (Int) -> Unit) {
    var name by remember { mutableStateOf("") }; var th by remember { mutableIntStateOf(1) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Мои карты", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Нажмите — выбрать, проведите — повернуть", fontSize = 12.sp, color = Color.Gray)
        s.cards.forEachIndexed { i, c ->
            Column(Modifier.padding(vertical = 8.dp)) {
                CardView(c, s.holder, s.hidden, Modifier.border(if (c.id == cur.id) 3.dp else 0.dp, Gold, RoundedCornerShape(26.dp)), onTap = { pick(i) })
                if (s.cards.size > 1) TextButton({ s.delCard(c.id) }) { Text("Удалить карту", color = Color(0xFFC62828)) } } }
        Text("Новая виртуальная карта", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Tf("Название", name, { name = it })
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { themeNames.forEachIndexed { i, n -> FilterChip(th == i, { th = i }, { Text(n, fontSize = 12.sp) }) } }
        Spacer(Modifier.height(8.dp)); Btn("Создать карту") { s.addCard(name, th); name = "" }
    }
}

@Composable fun Pay(s: Store, card: Card) {
    var kind by remember { mutableStateOf("transfer") }; var to by remember { mutableStateOf("") }
    var amt by remember { mutableStateOf("") }; var msg by remember { mutableStateOf("") }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Платежи", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(kind == "transfer", { kind = "transfer" }, { Text("Перевод") }); FilterChip(kind == "out", { kind = "out" }, { Text("Платёж") }) }
        Text("Со счёта: ${card.name} •• ${card.last4} (${money(card.balance)})", color = Color.Gray, fontSize = 13.sp)
        Tf(if (kind == "transfer") "Получатель" else "Назначение платежа", to, { to = it })
        Tf("Сумма, ₺", amt, { amt = it }, num = true)
        if (msg.isNotEmpty()) Text(msg, color = Color(0xFFC62828))
        Spacer(Modifier.height(8.dp))
        Btn("Отправить") {
            val a = amt.num()
            when { a == null || a <= 0 -> msg = "Введите сумму"; a > card.balance -> msg = "Недостаточно средств"
                else -> { s.apply(card.id, to.ifBlank { if (kind == "transfer") "Перевод" else "Платёж" }, if (kind == "transfer") "Перевод" else "Платёж", -a, kind); to = ""; amt = ""; msg = "" } }
        }
    }
}

@Composable fun History(s: Store, back: () -> Unit) {
    var f by remember { mutableIntStateOf(0) }
    val list = s.txs.filter { when (f) { 1 -> it.amount > 0; 2 -> it.amount < 0; else -> true } }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp)) {
        TextButton(back) { Text("← Назад", color = Green) }
        Text("История операций", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.padding(vertical = 8.dp), Arrangement.spacedBy(8.dp)) {
            listOf("Все", "Поступления", "Расходы").forEachIndexed { i, n -> FilterChip(f == i, { f = i }, { Text(n) }) } }
        Text("Поступления: +${money(s.txs.filter { it.amount > 0 }.sumOf { it.amount })}", color = Color(0xFF1B7F4B), fontSize = 13.sp)
        Text("Расходы: ${money(s.txs.filter { it.amount < 0 }.sumOf { it.amount })}", color = Color(0xFFC62828), fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
        if (list.isEmpty()) Text("Операций пока нет", color = Color.Gray, modifier = Modifier.padding(8.dp))
        list.forEachIndexed { i, t -> key(f, t.id) { Appear(i) { TxRow(t) } } }
    }
}

@Composable fun Profile(s: Store, go: (String) -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Профиль", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Tf("Имя владельца", s.holder, { s.holder = it; s.save() })
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("★ Премиум-клиент", fontWeight = FontWeight.Bold); Text("Золотая рамка и шуточные привилегии", fontSize = 12.sp, color = Color.Gray) }
            Switch(s.premium, { s.togglePrem() }) }
        AnimatedVisibility(s.premium) { Column(Modifier.fillMaxWidth().padding(top = 8.dp).background(Color(0xFFFFF8E1), RoundedCornerShape(16.dp)).padding(14.dp)) {
            Text("Ваши привилегии", fontWeight = FontWeight.Bold, color = Color(0xFF7A5C00))
            privileges.forEach { Text("• $it", fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)) } } }
        Text("Шуточные уведомления", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp, bottom = 4.dp))
        funNotifs.forEachIndexed { i, n -> Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${n.first}  ${n.second}", fontSize = 13.sp, modifier = Modifier.weight(1f)); Switch(i in s.notifs, { s.toggleNf(i) }) } }
        Spacer(Modifier.height(10.dp)); Btn("Админ-панель (PIN)") { go("admin") }
        Spacer(Modifier.height(10.dp)); Btn("Сбросить все данные", color = Color(0xFFC62828)) { confirm = true }
        Text("Лира Pay — вымышленный банк. Приложение работает офлайн, не связано с реальными банками и платежами.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 16.dp))
    }
    if (confirm) AlertDialog({ confirm = false }, title = { Text("Сбросить всё?") }, text = { Text("Карты, балансы и операции будут удалены.") },
        confirmButton = { TextButton({ s.reset(); confirm = false }) { Text("Сбросить") } }, dismissButton = { TextButton({ confirm = false }) { Text("Отмена") } })
}

@Composable fun EditTx(t: Tx, done: (String, String, Double) -> Unit, off: () -> Unit) {
    var a by remember { mutableStateOf(t.title) }; var b by remember { mutableStateOf(t.desc) }; var c by remember { mutableStateOf(t.amount.toString()) }
    AlertDialog(off, title = { Text("Операция") },
        text = { Column { Tf("Название", a, { a = it }); Tf("Описание", b, { b = it }); Tf("Сумма (минус = расход)", c, { c = it }) } },
        confirmButton = { TextButton({ c.num()?.let { done(a, b, it) } }) { Text("Сохранить") } }, dismissButton = { TextButton(off) { Text("Отмена") } })
}

@Composable fun Admin(s: Store, start: Card, back: () -> Unit) {
    var ok by remember { mutableStateOf(false) }; var p by remember { mutableStateOf("") }
    var ci by remember { mutableIntStateOf(s.cards.indexOfFirst { it.id == start.id }.coerceAtLeast(0)) }
    var bal by remember { mutableStateOf("") }; var amt by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }; var desc by remember { mutableStateOf("") }
    var np by remember { mutableStateOf("") }; var ed by remember { mutableStateOf<Tx?>(null) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp)) {
        TextButton(back) { Text("← Назад", color = Green) }
        Text("Админ-панель", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (!ok) {
            Text("PIN по умолчанию: 1234 (смените внутри)", color = Color.Gray, fontSize = 12.sp)
            Tf("PIN", p, { p = it }, num = true, pw = true); Btn("Войти") { if (p == s.pin) ok = true }
        } else {
            val c = s.cards[ci.coerceIn(0, s.cards.lastIndex)]
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { s.cards.forEachIndexed { i, x -> FilterChip(ci == i, { ci = i }, { Text("${x.name} ${x.last4}", fontSize = 11.sp) }) } }
            Text("Баланс: ${money(c.balance)}", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
            Tf("Установить баланс, ₺", bal, { bal = it }, num = true)
            Btn("Установить") { bal.num()?.let { s.setBal(c.id, it); bal = "" } }
            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Новая операция", fontWeight = FontWeight.Bold)
            Tf("Сумма, ₺", amt, { amt = it }, num = true); Tf("Название", title, { title = it }); Tf("Описание", desc, { desc = it })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("Добавить", Modifier.weight(1f)) { amt.num()?.let { s.apply(c.id, title.ifBlank { "Поступление" }, desc.ifBlank { "Пополнение" }, kotlin.math.abs(it), "in"); amt = ""; title = ""; desc = "" } }
                Btn("Вычесть", Modifier.weight(1f), Color(0xFFC62828)) { amt.num()?.let { s.apply(c.id, title.ifBlank { "Списание" }, desc.ifBlank { "Расход" }, -kotlin.math.abs(it), "out"); amt = ""; title = ""; desc = "" } }
            }
            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Tf("Новый PIN", np, { np = it }, num = true); Btn("Сменить PIN") { if (np.length >= 4) { s.pin = np; s.save(); np = "" } }
            Text("Операции (нажмите ✎ / ✕)", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
            s.txs.filter { it.cardId == c.id }.forEach { t ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { TxRow(t) }
                    TextButton({ ed = t }) { Text("✎") }; TextButton({ s.del(t) }) { Text("✕", color = Color(0xFFC62828)) } } }
        }
    }
    ed?.let { t -> EditTx(t, { a, b, c -> s.edit(t, a, b, c); ed = null }) { ed = null } }
}
